# Starshe Star-Themed Rapper Website

This complete website includes:

- A star-themed design that matches the name Starshe
- Starshe's picture as the main background
- Music uploads with cover images
- Video uploads with thumbnails
- Music and video players directly on the website
- Two separate administrator accounts
- Upload and delete controls for both administrators
- Firebase Authentication
- Firestore database
- Firebase Cloud Storage

## Files

- index.html
- style.css
- app.js
- starshe.jpg
- firestore.rules
- storage.rules

## Step 1: Create the Firebase project

1. Open Firebase Console.
2. Create a project.
3. Add a Web App.
4. Copy the Firebase configuration.
5. Paste the values into firebaseConfig inside app.js.

## Step 2: Turn on administrator login

1. Open Firebase Authentication.
2. Choose Sign-in method.
3. Enable Email/Password.
4. Add Starshe as a user.
5. Add yourself as a second user.

Use separate passwords.

## Step 3: Add both administrator emails

Replace these examples everywhere:

- starshe@example.com
- your-email@example.com

Change them in:

- app.js
- firestore.rules
- storage.rules

The emails must match the accounts created in Firebase Authentication.

## Step 4: Create Firestore

1. Open Firestore Database.
2. Create the database.
3. Open Rules.
4. Copy all code from firestore.rules.
5. Paste and publish it.

## Step 5: Create Storage

1. Open Storage.
2. Set up Cloud Storage.
3. Open Rules.
4. Copy all code from storage.rules.
5. Paste and publish it.

## Step 6: Publish

Upload the files to GitHub Pages, Firebase Hosting, Netlify, or another HTTPS host.

Do not test by opening index.html with file:// because browser security may block JavaScript modules. Test through a local server or a published website.

## Upload limits in this starter

- Images: 10 MB
- Songs: 100 MB
- Videos: 500 MB
